#!/bin/bash

zip -r "botCustom.zip" * -x "botCustom.zip"